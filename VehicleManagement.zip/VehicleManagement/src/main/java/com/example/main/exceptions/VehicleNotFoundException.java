package com.example.main.exceptions;

public class VehicleNotFoundException extends RuntimeException {

	public VehicleNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public VehicleNotFoundException(String message) {
		super(message);
	}
}
